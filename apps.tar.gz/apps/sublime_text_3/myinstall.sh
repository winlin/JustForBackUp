#!/bin/sh
sudo ln -s `pwd`/sublime_text /usr/bin/sublime

